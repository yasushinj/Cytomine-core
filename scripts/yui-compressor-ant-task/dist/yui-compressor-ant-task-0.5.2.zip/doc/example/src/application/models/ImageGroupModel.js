/**
 * Created by laurent on 16.02.17.
 *
 */


var ImageGroupModel = Backbone.Model.extend({
    channel:"",
    zstack:0,
    time:"",
    slice:"",
    feeded:false,


    url: function () {
        var base = 'api/imagegroup';
        var format = '.json';
        if (this.isNew()) return base + format;
        return base + (base.charAt(base.length - 1) == '/' ? '' : '/') + this.id + format;
    },

    feed: function () {
        var self = this;
        var coll = new ImageSequenceCollection({group: this.id});
        coll.fetch({success: function (collection, response) {
            var iS = collection.at(0);
            if(self.feeded)
                return;
            $.get("/api/imageinstance/"+iS.attributes.image+"/imagesequence/possibilities.json", function(data) {

                if(data.channel!=null && data.channel!=undefined) {
                    self.channel=data.channel;
                    self.slice=data.slice;
                    self.time=data.time;
                }
            });
            self.feeded=true;
        },
        error: function (collection, response) {
            console.log(response);
        }});

    }
});

var ImageGroupCollection = PaginatedCollection.extend({
    model: ImageGroupModel,
    url: function() {

        var format = '.json';
        return "api/project/"+ this.project + "/imagegroup" + format;
    },

    initialize: function (options) {
      this.project=options.project;
    }
});